package com.in28minutes.java.classmodifiers.nonaccess.finalclass;

final public class FinalClass {
}

// Below class will not compile if uncommented
// FinalClass cannot be extended
/*
 * class ExtendingFinalClass extends FinalClass{
 * 
 * }
 */