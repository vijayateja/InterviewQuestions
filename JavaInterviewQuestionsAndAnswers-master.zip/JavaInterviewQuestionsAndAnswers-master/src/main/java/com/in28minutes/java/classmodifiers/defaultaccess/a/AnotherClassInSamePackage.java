package com.in28minutes.java.classmodifiers.defaultaccess.a;

public class AnotherClassInSamePackage {
	// DefaultAccessClass and AnotherClassInSamePackage
	// are in same package.
	// So, DefaultAccessClass is visible.
	// An instance of the class can be created.

	DefaultAccessClass defaultAccess;
}
