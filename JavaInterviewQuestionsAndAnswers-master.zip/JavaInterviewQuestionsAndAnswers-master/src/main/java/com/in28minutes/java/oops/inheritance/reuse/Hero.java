package com.in28minutes.java.oops.inheritance.reuse;

//IS-A relationship. Hero is-a Actor
public class Hero extends Actor {
	public void fight() {
		System.out.println("fight");
	};
}
