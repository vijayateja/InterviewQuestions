package com.in28minutes.java.classmodifiers.defaultaccess.a;

/* No public before class. So this class has default access*/
class DefaultAccessClass {
	// Default access is also called package access
}
