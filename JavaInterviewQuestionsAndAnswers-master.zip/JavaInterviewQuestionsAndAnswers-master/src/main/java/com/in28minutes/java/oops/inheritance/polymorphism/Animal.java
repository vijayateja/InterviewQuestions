package com.in28minutes.java.oops.inheritance.polymorphism;

public class Animal {
	public String shout() {
		return "Don't Know!";
	}
}
