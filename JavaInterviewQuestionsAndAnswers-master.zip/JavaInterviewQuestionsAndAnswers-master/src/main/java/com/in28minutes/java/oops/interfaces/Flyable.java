package com.in28minutes.java.oops.interfaces;

public interface Flyable {
	void fly();
}
