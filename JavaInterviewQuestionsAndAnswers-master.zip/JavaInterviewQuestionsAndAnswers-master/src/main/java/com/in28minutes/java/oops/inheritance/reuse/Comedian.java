package com.in28minutes.java.oops.inheritance.reuse;

//IS-A relationship. Comedian is-a Actor
public class Comedian extends Actor {
	public void performComedy() {
		System.out.println("Comedy");
	};
}
