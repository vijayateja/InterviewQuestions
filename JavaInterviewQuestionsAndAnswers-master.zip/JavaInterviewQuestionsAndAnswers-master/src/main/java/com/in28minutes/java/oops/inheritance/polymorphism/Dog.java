package com.in28minutes.java.oops.inheritance.polymorphism;

class Dog extends Animal {
	public String shout() {
		return "BOW BOW";
	}

	public void run() {

	}
}
