package com.in28minutes.java.oops.interfaces;
public class Bird implements Flyable {
	public void fly() {
		System.out.println("Bird is flying");
	}
}
